package game

type ScoringStrategy interface {
	Calculate(word string) int
}

type BasicStrategy struct{}

func (b *BasicStrategy) Calculate(word string) int {
	if len(word) <= 4 {
		return 1
	}
	return len(word)
}

type BonusStrategy struct{}

func (b *BonusStrategy) Calculate(word string) int {
	points := len(word)
	if len(word) >= 6 {
		points += 3
	}
	return points
}
